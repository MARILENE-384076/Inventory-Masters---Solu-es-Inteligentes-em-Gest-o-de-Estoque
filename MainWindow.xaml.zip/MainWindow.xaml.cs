﻿using Microsoft.Kinect;
using Microsoft.AspNetCore.SignalR.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace AppInterfaceKinectUnificado
{
    public partial class MainWindow : Window
    {
        private KinectSensor sensor;

        // Color
        private byte[] colorPixels;
        private WriteableBitmap colorBitmap;

        // Depth
        private DepthImagePixel[] depthPixels;
        private WriteableBitmap depthBitmap;

        // Calibração / volume
        private int[] referenciaChao;
        private bool calibrado = false;

        private Queue<double> historicoVolume = new Queue<double>();
        private const int MAX_HISTORICO_VOLUME = 30;   // mais frames para suavizar
        private const int LIMITE_MINIMO_ALTURA_MM = 30; // ignora < 3 cm

        private double ultimoVolumeSuavizado = 0;

        // SignalR
        private HubConnection hubConnection;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            Unloaded += MainWindow_Unloaded;
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                // Inicializa Hub SignalR
                hubConnection = new HubConnectionBuilder()
                    .WithUrl("http://localhost:5000/kinectHub") // <-- ajuste a URL conforme sua API Razor
                    .WithAutomaticReconnect()
                    .Build();

                await hubConnection.StartAsync();
                StatusTextBlock.Text = "Conectado ao servidor SignalR.";
                await hubConnection.InvokeAsync("EnviarMensagem", "WPF conectado com sucesso!");

                // --- Kinect ---
                sensor = KinectSensor.KinectSensors.FirstOrDefault(s => s.Status == KinectStatus.Connected);
                if (sensor == null)
                {
                    StatusTextBlock.Text = "Nenhum Kinect conectado.";
                    await hubConnection.InvokeAsync("EnviarMensagem", "Nenhum Kinect encontrado.");
                    return;
                }

                // --- Color ---
                sensor.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);
                colorPixels = new byte[sensor.ColorStream.FramePixelDataLength];
                colorBitmap = new WriteableBitmap(sensor.ColorStream.FrameWidth, sensor.ColorStream.FrameHeight,
                                                  96, 96, PixelFormats.Bgr32, null);
                CameraImage.Source = colorBitmap;
                sensor.ColorFrameReady += Sensor_ColorFrameReady;

                // --- Depth ---
                sensor.DepthStream.Enable(DepthImageFormat.Resolution320x240Fps30);
                depthPixels = new DepthImagePixel[sensor.DepthStream.FramePixelDataLength];
                depthBitmap = new WriteableBitmap(sensor.DepthStream.FrameWidth, sensor.DepthStream.FrameHeight,
                                                  96, 96, PixelFormats.Gray16, null);
                sensor.DepthFrameReady += Sensor_DepthFrameReady;

                sensor.Start();
                StatusTextBlock.Text = "Kinect inicializado. Clique em 'Calibrar Chão'.";

                await hubConnection.InvokeAsync("EnviarMensagem", "Kinect inicializado e pronto.");
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = $"Erro ao inicializar: {ex.Message}";
            }
        }

        private async void MainWindow_Unloaded(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sensor != null && sensor.IsRunning)
                    sensor.Stop();

                if (hubConnection != null)
                    await hubConnection.DisposeAsync();
            }
            catch { }
        }

        private void Sensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (var frame = e.OpenColorImageFrame())
            {
                if (frame == null) return;

                frame.CopyPixelDataTo(colorPixels);
                colorBitmap.WritePixels(new Int32Rect(0, 0, frame.Width, frame.Height),
                                        colorPixels, frame.Width * 4, 0);
            }
        }

        private void Sensor_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        {
            using (var frame = e.OpenDepthImageFrame())
            {
                if (frame == null) return;

                frame.CopyDepthImagePixelDataTo(depthPixels);

                var raw = new ushort[frame.Width * frame.Height];
                for (int i = 0; i < raw.Length; i++)
                    raw[i] = (ushort)depthPixels[i].Depth;

                depthBitmap.WritePixels(new Int32Rect(0, 0, frame.Width, frame.Height),
                                        raw, frame.Width * 2, 0);

                if (calibrado && referenciaChao != null)
                    CalcularVolume();
            }
        }

        private void CalibrarChao_Click(object sender, RoutedEventArgs e)
        {
            if (sensor == null || !sensor.IsRunning)
            {
                StatusTextBlock.Text = "Kinect não inicializado.";
                return;
            }
            if (depthPixels == null || depthPixels.Length == 0)
            {
                StatusTextBlock.Text = "Sem dados de profundidade para calibrar.";
                return;
            }

            referenciaChao = new int[depthPixels.Length];
            for (int i = 0; i < depthPixels.Length; i++)
                referenciaChao[i] = depthPixels[i].Depth;

            calibrado = true;
            historicoVolume.Clear();
            ultimoVolumeSuavizado = 0;
            VolumeTextBlock.Text = "Volume: 0 cm³";
            StatusTextBlock.Text = "Calibração concluída. Coloque o objeto na frente da câmera.";
        }

        private void ToggleKinect_Click(object sender, RoutedEventArgs e)
        {
            if (sensor == null) return;

            if (sensor.IsRunning)
            {
                sensor.Stop();
                ToggleKinectButton.Content = "Ligar Kinect";
                StatusTextBlock.Text = "Kinect desligado.";
                CameraImage.Source = null;
            }
            else
            {
                sensor.Start();
                ToggleKinectButton.Content = "Desligar Kinect";
                StatusTextBlock.Text = "Kinect ligado.";
                CameraImage.Source = colorBitmap;
            }
        }

        private async void CalcularVolume()
        {
            double horizontalFOV = 57 * Math.PI / 180.0;
            double verticalFOV = 43 * Math.PI / 180.0;

            int width = sensor.DepthStream.FrameWidth;
            int height = sensor.DepthStream.FrameHeight;

            double volumeTotal = 0;

            for (int i = 0; i < depthPixels.Length; i++)
            {
                int current = depthPixels[i].Depth;
                int reference = referenciaChao[i];

                if (current <= 0 || reference <= 0 || current >= reference)
                    continue;

                int delta = reference - current;

                if (delta < LIMITE_MINIMO_ALTURA_MM)
                    continue;

                double altura = delta / 1000.0;
                double distancia = current / 1000.0;

                double pixelWidth = 2 * distancia * Math.Tan(horizontalFOV / 2) / width;
                double pixelHeight = 2 * distancia * Math.Tan(verticalFOV / 2) / height;
                double pixelArea = pixelWidth * pixelHeight;

                volumeTotal += altura * pixelArea;
            }

            double volumeCm3 = volumeTotal * 1_000_000;

            historicoVolume.Enqueue(volumeCm3);
            if (historicoVolume.Count > MAX_HISTORICO_VOLUME)
                historicoVolume.Dequeue();

            double mediaHistorico = historicoVolume.Average();
            double peso = 0.7;
            double volumeSuavizado = ultimoVolumeSuavizado * peso + mediaHistorico * (1 - peso);
            ultimoVolumeSuavizado = volumeSuavizado;

            double finalVolume = volumeSuavizado > 0 ? volumeSuavizado : 0;
            VolumeTextBlock.Text = $"Volume: {finalVolume:F0} cm³";

            // Envia para o Razor via SignalR
            if (hubConnection != null && hubConnection.State == HubConnectionState.Connected)
            {
                await hubConnection.InvokeAsync("EnviarMensagem", $"Volume atual: {finalVolume:F0} cm³");
            }
        }
    }
}
